using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Hit : StateMachineBehaviour
{

    public GameObject player;
    private BoxCollider attackbox;
    override public void OnStateEnter(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    {
       attackbox = player.GetComponent<BoxCollider>();
       attackbox.enabled = attackbox.enabled;
    }
    override public void OnStateExit(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    {
       attackbox.enabled = !attackbox.enabled;
    }
}
