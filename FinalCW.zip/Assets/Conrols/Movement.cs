using System;
using System.Runtime.Serialization;
using UnityEngine;
using UnityEngine.InputSystem;

public class Movement : MonoBehaviour
    {
        public GameObject model;
        public Rigidbody rb;
        private float speed;
        public float sensentivity;
        private Vector3 direction;
        public InputActionReference move;

        public InputActionReference rotate;
        public InputActionReference attack;

        public InputActionReference block;

        public InputActionReference RunModifier;
        public float runningMult;
        public float defaultSpeed;
        private Vector2 rotations;
        private float rotated;
        private Vector3 movement;

        public BoxCollider attackbox;

        private bool running;

        

        private PlayerHealth healthScript;


    public void DisableHitbox()
    {
        GameObject obj = GameObject.Find("mixamorig:LeftHand");
        obj.GetComponent<BoxCollider>().enabled = false;

    }

    public void EnableHitbox(){
        GameObject obj = GameObject.Find("mixamorig:LeftHand");
        obj.GetComponent<BoxCollider>().enabled = true;
    }
    void Start()

    {
        Cursor.lockState = CursorLockMode.Locked;


        healthScript = gameObject.GetComponentInParent<PlayerHealth>();
        
    }
    void Update()
    {
       
    }

    void FixedUpdate()
    {
        direction = move.action.ReadValue<Vector3>();
        rotations = rotate.action.ReadValue<Vector2>();
        rotated += Math.Clamp(rotations.x,-10,10);
        running = RunModifier.action.IsPressed();
        Quaternion angle = Quaternion.Euler(0, rotated*sensentivity, 0 );
        if (direction.z*speed != 0){
            model.GetComponent<Animator>().SetBool("Walk", true);
        } else {
            model.GetComponent<Animator>().SetBool("Walk", false);
        }
        if (direction.x*speed != 0){
            model.GetComponent<Animator>().SetBool("Walk side", true);
        } else {
            model.GetComponent<Animator>().SetBool("Walk side", false);
        }
        if (running)
        {
            speed = defaultSpeed * runningMult;
        }
        else
        {
            speed = defaultSpeed;
        }
        movement = new Vector3(direction.x*speed, 0, direction.z*speed);
        rb.rotation = angle;
        rb.velocity = angle * movement;
    }

    private void OnEnable()
    {
        attack.action.started += Attack;
        block.action.started += Block;
    }

    private void Attack(InputAction.CallbackContext obj)
    {

        if (!healthScript.isAttacking && !healthScript.isBlocking)
            model.GetComponent<Animator>().SetTrigger("Attack");
            healthScript.isAttacking = true;
    }

    private void Block(InputAction.CallbackContext obj)
    {
        if (!healthScript.isBlocking && !healthScript.isAttacking)
        {
            model.GetComponent<Animator>().SetTrigger("Block");


            healthScript.isBlocking = true;
            healthScript.shield.SetActive(true);

        }
        
    }
    private void OnDisable()
    {
        attack.action.started -= Attack;
        attack.action.started -= Block;
    }
}
