using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraScript : MonoBehaviour
{
    // Start is called before the first frame update
    [SerializeField] private GameObject player;
    [SerializeField] private int cameraHeight;
    [SerializeField] private float cameraZOffset;
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        Vector3 cameraPosition = player.transform.position;
        cameraPosition.y = cameraPosition.y + cameraHeight;
        cameraPosition.z = cameraPosition.z + cameraZOffset;
        transform.position = cameraPosition;
    }
}
