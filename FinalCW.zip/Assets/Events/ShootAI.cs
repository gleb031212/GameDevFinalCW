using UnityEngine;

public class ShootAI : MonoBehaviour
{
    public float preferredDistance = 3f;
    public float attackDistance = 2f;
    public float maxSpeed = 5f;
    public float accelerationFactor = 2f;
    public float orbitSpeed = 2f;
    public float deadZone = 0.5f;

    private int minRange = 3;
    public float projectileSpeed = 10f;
    public float chargeTime = 2f;
    public float attackDuration = 1f;
    public GameObject attackPrefab;

    private Rigidbody rb;
    private Rigidbody target;
    private Renderer rend;

    private bool rotateClockwise;
    private bool isOnCooldown = true;
    private float attackTimer = 0f;
    private float cooldownTimer = 0f;

    private Color originalMaterial;

    private enum AttackState { None, Charging, Cooldown }
    private AttackState currentState = AttackState.Cooldown;

    private RigidbodyConstraints persistentConstraints = RigidbodyConstraints.FreezePositionY | RigidbodyConstraints.FreezeRotationX | RigidbodyConstraints.FreezeRotationZ;

    void Start()
    {
        rb = GetComponent<Rigidbody>();
        GameObject playerObj = GameObject.Find("Wholeplayer");
        target = playerObj.GetComponent<Rigidbody>();
        rotateClockwise = Random.value > 0.5f;

        rend = GetComponent<Renderer>();
        rb.constraints = persistentConstraints;

        if (rend != null)
        {
            originalMaterial = rend.material.color;
        }
    }

    void FixedUpdate()
    {
        if (target == null) return;

        Vector3 toTarget = target.position - rb.position;
        float distance = toTarget.magnitude;

        switch (currentState)
        {
            case AttackState.None:
                if (distance <= attackDistance && distance > minRange && !isOnCooldown)
                {
                    StartCharging();
                }
                else
                {
                    MoveTowardsTarget(toTarget);
                }
                break;

            case AttackState.Charging:
                attackTimer += Time.fixedDeltaTime;
                if (attackTimer >= chargeTime)
                {
                    ExecuteAttack(toTarget.normalized);
                    StartCooldown();
                }
                break;

            case AttackState.Cooldown:
                cooldownTimer += Time.fixedDeltaTime;
                if (cooldownTimer >= 2f)
                {
                    currentState = AttackState.None;
                    isOnCooldown = false;
                }
                MoveTowardsTarget(toTarget);
                break;
        }
    }

    void StartCharging()
    {
        currentState = AttackState.Charging;
        isOnCooldown = true;
        attackTimer = 0f;

        rb.velocity = Vector3.zero;
        rb.angularVelocity = Vector3.zero;
        rb.constraints = RigidbodyConstraints.FreezeAll;

        if (rend != null)
            rend.material.color = Color.red;
    }

    void ExecuteAttack(Vector3 unused)
    {
        if (rend != null)
            rend.material.color = Color.green;

        rb.constraints = persistentConstraints;

        Vector3 flatDir = target.position - transform.position;
        flatDir.y = 0f;
        Vector3 forwardDir = flatDir.normalized;

        Vector3 spawnPos = transform.position + forwardDir;
        GameObject projectile = Instantiate(attackPrefab, transform.position, Quaternion.identity);
        Rigidbody projRb = projectile.GetComponent<Rigidbody>();
        if (projRb != null)
        {
            projRb.velocity = forwardDir * projectileSpeed;
        }
    }

    void StartCooldown()
    {
        currentState = AttackState.Cooldown;
        cooldownTimer = 0f;

        if (rend != null)
            rend.material.color = originalMaterial;

        rb.constraints = persistentConstraints;
    }

    void MoveTowardsTarget(Vector3 toTarget)
    {
        rb.constraints = persistentConstraints;

        float distance = toTarget.magnitude;
        float distanceDelta = distance - preferredDistance;
        float radialSpeed = Mathf.Clamp(distanceDelta * accelerationFactor, -maxSpeed, maxSpeed);
        Vector3 radialDir = toTarget.normalized;

        Vector3 tangentialDir = Vector3.Cross(Vector3.up, radialDir).normalized;
        if (!rotateClockwise)
            tangentialDir *= -1;

        Vector3 velocity = radialDir * radialSpeed + tangentialDir * orbitSpeed;
        rb.velocity = Vector3.ClampMagnitude(velocity, maxSpeed);
    }
}