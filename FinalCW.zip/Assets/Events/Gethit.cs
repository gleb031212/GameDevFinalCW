using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class Gethit : MonoBehaviour
{
    public int HitCounter = 0;

    private TextMeshProUGUI ScoreCounter;
    void OnTriggerEnter(Collider hitter)

    {
        if (hitter.CompareTag("playerAttack"))
        {
            GameManager.Instance.AddScore(1);
            ScoreCounter.text = string.Format("Score: {0}\n Health:{1}", GameManager.Instance.TotalScore, hitter.GetComponentInParent<PlayerHealth>().currentHealth);
            hitter.GetComponentInParent<PlayerHealth>().ApplyHeal(5);
            Destroy(gameObject);
            
        }
    }
        void Start()
        {
            ScoreCounter = GameObject.Find("ScoreUI").GetComponent<TextMeshProUGUI>();
        }
}
