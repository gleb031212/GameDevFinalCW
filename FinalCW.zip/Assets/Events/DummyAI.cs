using UnityEngine;

public class DummyAI : MonoBehaviour
{
    public float preferredDistance = 3f;

    public float attackDistance = 2f;
    public float maxSpeed = 5f;
    public float accelerationFactor = 2f;
    public float orbitSpeed = 2f;
    public float deadZone = 0.5f;

    public float chargeTime = 2f;
    public float attackDuration = 1f;
    public GameObject attackPrefab;

    private Rigidbody rb;
    private Rigidbody target;
    private Renderer rend;

    private bool rotateClockwise;
    private bool isAttacking = false;
    private bool isOnCooldown = false;

    private float attackTimer = 0f;
    private float cooldownTimer = 0f;

    private enum AttackState { None, Charging, Attacking, Cooldown }
    private AttackState currentState = AttackState.None;

    private RigidbodyConstraints persistentConstraints = RigidbodyConstraints.FreezePositionY | RigidbodyConstraints.FreezeRotationX | RigidbodyConstraints.FreezeRotationZ;

    void Start()
    {
        rb = GetComponent<Rigidbody>();
        GameObject playerObj = GameObject.Find("Wholeplayer");
        target = playerObj.GetComponent<Rigidbody>();
        rotateClockwise = Random.value > 0.5f;

        rend = GetComponent<Renderer>();
        rb.constraints = persistentConstraints;
    }
}
