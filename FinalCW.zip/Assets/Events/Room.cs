using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Room : MonoBehaviour
{
    public int numberOfEnemies;

    [HideInInspector] public int roomNumber;

    public DummySpawner[] spawners;


    public GameObject door;

    private float baseSpawnInterval = 5f;

    private float fastestSpawnInterval = 0.5f;

    private int maxDifficultyRoom = 11;

    private int baseMaxDummies = 2;

    private float maxMaxDummies = 10;
    public void openDoor()
    {
        door.SetActive(false);
    }

    public void Initialize(int room)
    {
        if (room == 0)
        {
            foreach (DummySpawner spawner in spawners)
            {

                spawner.SetSpawnInterval(1);
                spawner.SetMaxDummies(2);

                spawner.SetSpawnMode(SpawnMode.Tutorial);
            }
        }
        else if (room == 1)
        {
            foreach (DummySpawner spawner in spawners)
            {

                spawner.SetSpawnInterval(baseSpawnInterval);
                spawner.SetMaxDummies(baseMaxDummies);

                spawner.SetSpawnMode(SpawnMode.Melee);
            }
        }
        else
        {


            foreach (DummySpawner spawner in spawners)
            {
                float spawnInterval = Mathf.Lerp(baseSpawnInterval, fastestSpawnInterval, (float)room / maxDifficultyRoom);
                int maxDummies = (int)Mathf.Lerp(baseMaxDummies, maxMaxDummies, (float)room / maxDifficultyRoom);
                spawner.SetSpawnInterval(spawnInterval);
                spawner.SetMaxDummies(maxDummies);

                int randomNumber = Random.Range(1, 3);
                spawner.SetSpawnMode((SpawnMode)randomNumber);


            }
        }
    }

    public void DestroySpawners()
    {
        foreach (DummySpawner spawner in spawners)
        {

            Destroy(spawner);
        }
        foreach (Transform child in transform)
        {
            if (child.CompareTag("Dummy"))
            {
                Destroy(child.gameObject);
            }
        }
    }

    private void OnDisable()
    {
        GameManager.Instance.onRoomUnlock -= openDoor;
    }


}
