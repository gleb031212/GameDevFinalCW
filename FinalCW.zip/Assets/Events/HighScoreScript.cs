using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
#if UNITY_EDITOR
using UnityEditor;
using UnityEditor.SearchService;
#endif

public class HighScoreScript : MonoBehaviour
{
    [SerializeField] private TextMeshProUGUI YourScore;
    [SerializeField] private TextMeshProUGUI HighScore;
    void Start()
    {   

        Cursor.lockState = CursorLockMode.Confined;
        if (YourScore)
        {
             YourScore.text = "Your Score: " + GameManager.Instance.TotalScore;
        }
        if (HighScore)
        {
             HighScore.text = "High Score: " + PlayerPrefs.GetInt("High Score");
        }
        
    }
}
