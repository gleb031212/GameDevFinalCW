using UnityEngine;

public class Backup : MonoBehaviour
{
    public float preferredDistance = 3f;

    public float attackDistance = 2f;
    public float maxSpeed = 5f;
    public float accelerationFactor = 2f;
    public float orbitSpeed = 2f;
    public float deadZone = 0.5f;

    public float chargeTime = 2f;
    public float attackDuration = 1f;
    public GameObject attackPrefab;

    private Rigidbody rb;
    private Rigidbody target;
    private Renderer rend;

    private bool rotateClockwise;
    private bool isAttacking = false;
    private bool isOnCooldown = false;

    private float attackTimer = 0f;
    private float cooldownTimer = 0f;

    private enum AttackState { None, Charging, Attacking, Cooldown }
    private AttackState currentState = AttackState.None;

    private RigidbodyConstraints persistentConstraints = RigidbodyConstraints.FreezePositionY | RigidbodyConstraints.FreezeRotationX | RigidbodyConstraints.FreezeRotationZ;

    void Start()
    {
        rb = GetComponent<Rigidbody>();
        GameObject playerObj = GameObject.Find("Wholeplayer");
        target = playerObj.GetComponent<Rigidbody>();
        rotateClockwise = Random.value > 0.5f;

        rend = GetComponent<Renderer>();
        rb.constraints = persistentConstraints;
    }

    void FixedUpdate()
    {
        if (target == null) return;

        Vector3 toTarget = target.position - rb.position;
        float distance = toTarget.magnitude;

        switch (currentState)
        {
            case AttackState.None:
                if (distance <= attackDistance && !isOnCooldown)
                {
                    StartCharging();
                }
                else
                {
                    MoveTowardsTarget(toTarget);
                }
                break;

            case AttackState.Charging:
                attackTimer += Time.fixedDeltaTime;
                if (attackTimer >= chargeTime)
                {
                    ExecuteAttack(toTarget.normalized);
                }
                break;

            case AttackState.Attacking:
                attackTimer += Time.fixedDeltaTime;
                if (attackTimer >= attackDuration)
                {
                    FinishAttack();
                }
                break;

            case AttackState.Cooldown:
                cooldownTimer += Time.fixedDeltaTime;
                if (cooldownTimer >= 0.5f)
                {
                    currentState = AttackState.None;
                    isOnCooldown = false;
                }
                break;
        }
    }

    void StartCharging()
    {
        currentState = AttackState.Charging;
        isAttacking = true;
        isOnCooldown = true;
        attackTimer = 0f;

        rb.velocity = Vector3.zero;
        rb.angularVelocity = Vector3.zero;
        rb.constraints = RigidbodyConstraints.FreezeAll;

        if (rend != null)
            rend.material.color = Color.red;
    }

    void ExecuteAttack(Vector3 forwardDir)
    {
        currentState = AttackState.Attacking;
        attackTimer = 0f;

        if (rend != null)
            rend.material.color = Color.green;

        rb.constraints = persistentConstraints;
        Vector3 spawnPos = transform.position + forwardDir;
        Instantiate(attackPrefab, spawnPos, Quaternion.identity);
    }

    void FinishAttack()
    {
        currentState = AttackState.Cooldown;
        cooldownTimer = 0f;
        if (rend != null)
            rend.material.color = Color.white;
        rb.velocity = Vector3.zero;
        rb.constraints = persistentConstraints;
        isAttacking = false;
    }

    void MoveTowardsTarget(Vector3 toTarget)
    {
        if (isAttacking) return;

        rb.constraints = persistentConstraints;

        float distance = toTarget.magnitude;
        float distanceDelta = distance - preferredDistance;
        float radialSpeed = Mathf.Clamp(distanceDelta * accelerationFactor, -maxSpeed, maxSpeed);
        Vector3 radialDir = toTarget.normalized;

        Vector3 tangentialDir = Vector3.Cross(Vector3.up, radialDir).normalized;
        if (!rotateClockwise)
            tangentialDir *= -1;

        Vector3 velocity = radialDir * radialSpeed + tangentialDir * orbitSpeed;
        rb.velocity = Vector3.ClampMagnitude(velocity, maxSpeed);
    }
}
