using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    [SerializeField] private GameObject[] roomPrefabs;

    public int TotalScore = 0;
    public int scoreToUnlockNextRoom = 4;
    private GameObject currentRoom;

    private int roomsSpawned = 0;

    public event Action onRoomUnlock;

    public static GameManager Instance { get; private set; }

    void Start()
    {

        SceneManager.sceneLoaded += OnSceneLoaded;

        
    }

    void Update()
    {
        if (roomsSpawned == 0)
        {
          SpawnRoom(0);  
        }
        
    }


    void SpawnRoom(int index)
    {
        GameObject roomToSpawn;
        if (index >= 0 && index < roomPrefabs.Length)
        {
            roomToSpawn = roomPrefabs[index];
        }
        else
        {
            roomToSpawn = roomPrefabs[UnityEngine.Random.Range(1, roomPrefabs.Length)];
        }

        GameObject newRoom = Instantiate(roomToSpawn, new Vector3(10 * roomsSpawned, 2.5f, 0), Quaternion.identity);
        currentRoom = newRoom;
        Room roomScript = newRoom.GetComponent<Room>();
        roomScript.Initialize(roomsSpawned);
        roomsSpawned++;
        onRoomUnlock += roomScript.openDoor;
    }

    public void AddScore(int score)
    {
        TotalScore += score;

        if (TotalScore >= scoreToUnlockNextRoom)
        {

            Room roomScript = currentRoom.GetComponent<Room>();
            roomScript.DestroySpawners();
            onRoomUnlock?.Invoke();
            SpawnRoom(-1);
            if (scoreToUnlockNextRoom == 4)
            {
                scoreToUnlockNextRoom = 10;
            }
            else
            {
                scoreToUnlockNextRoom += 10;
            }


        }
    }

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;
        DontDestroyOnLoad(gameObject);
    }


    private void OnSceneLoaded(Scene scene, LoadSceneMode mode)
    {
        if (scene.buildIndex == 1)
        {
            roomsSpawned = 0;
            scoreToUnlockNextRoom = 4;
            TotalScore = 0;
        }
    }

    public void EndGame()
    {
        if (PlayerPrefs.GetInt("High Score") < TotalScore)
        {
            PlayerPrefs.SetInt("High Score", TotalScore);

        }
        SceneManager.LoadScene(2);
    }

}
