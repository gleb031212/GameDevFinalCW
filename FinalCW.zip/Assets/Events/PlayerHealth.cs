using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using System.Threading;
public class PlayerHealth : MonoBehaviour
{
    public int maxHealth = 100;
    public int currentHealth;
    public float blockTime;

    public float attackTime;
    public float cooldownBlock;
    public bool isBlocking = false;
    public bool isAttacking = false;

    public bool isOnCooldown = false;

    private float timer;
    private float timerBlock;
    private float timerCooldown;
    public GameObject shield;
    void Start()
    {
        currentHealth = maxHealth;

    }

    public void ApplyDamage(int damage)
    {

        if (!isBlocking)
        {
            currentHealth -= damage;
            Debug.Log("Player hit! Current HP: " + currentHealth);
            TextMeshProUGUI UI = GameObject.Find("ScoreUI").GetComponent<TextMeshProUGUI>();
            UI.text = string.Format("Score: {0}\nHealth:{1}", GameManager.Instance.TotalScore, currentHealth);

            if (currentHealth <= 0)
            {
                Debug.Log("Player died.");
                GameManager.Instance.EndGame();
            }
        }
    }

    public void ApplyHeal(int health)
    {


        if (currentHealth < 90)
        {
            currentHealth += health;
            TextMeshProUGUI UI = GameObject.Find("ScoreUI").GetComponent<TextMeshProUGUI>();
            UI.text = string.Format("Score: {0}\nHealth:{1}", GameManager.Instance.TotalScore, currentHealth);

        }
        else if (currentHealth < 100)
        {
            TextMeshProUGUI UI = GameObject.Find("ScoreUI").GetComponent<TextMeshProUGUI>();
            UI.text = string.Format("Score: {0}\nHealth:{1}", GameManager.Instance.TotalScore, currentHealth);
            currentHealth = 100;
        }
    }

    void Update()
    {

        if (isOnCooldown)
        {
            timerCooldown += Time.deltaTime;
            if (timerCooldown >= cooldownBlock)
            {
                isOnCooldown = false;
                timerCooldown = 0;
            }
        }

        if (isBlocking)
        {
            timerBlock += Time.deltaTime;
            if (timerBlock >= blockTime)
            {
                isBlocking = false;
                shield.SetActive(false);
                timerBlock = 0;
                isOnCooldown = true;
            }
        }

        if (isAttacking)
        {
            timer += Time.deltaTime;
            if (timer >= attackTime)
            {
                isAttacking = false;
                timer = 0;
            }
        }
    }

}

