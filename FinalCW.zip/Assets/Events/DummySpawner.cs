using UnityEngine;

public enum SpawnMode
    {
        Tutorial,
        Melee,
        Ranged
    }
public class DummySpawner : MonoBehaviour
{
    private GameObject prefabToSpawn;

    public GameObject[] dummyPrefabs;
    public float spawnInterval = 5f;



    private SpawnMode mode = SpawnMode.Tutorial;
    private Transform spawnPoint;
    public int maxDummies = 4;

    private float timer = 0f;

    void Start()
    {
        if (spawnPoint == null)
        {
            spawnPoint = transform;
        }
    }

    void Update()
    {
        timer += Time.deltaTime;

        if (timer >= spawnInterval)
        {
            if (CountActiveDummies() < maxDummies)
            {
                SpawnDummy();
            }
            timer = 0f;
        }
    }

    void SpawnDummy()
    {
        Instantiate(prefabToSpawn, spawnPoint.position, spawnPoint.rotation, transform.parent);
    }

    int CountActiveDummies()
    {
        return GameObject.FindGameObjectsWithTag("Dummy").Length;
    }

    public void SetSpawnMode(SpawnMode newMode)
    {
        mode = newMode;
        prefabToSpawn = dummyPrefabs[(int)mode];
    }

    public void SetSpawnInterval(float time)
    {
        spawnInterval = time;
    }
    public void SetMaxDummies(int max)
    {
        maxDummies = max;
    }
}